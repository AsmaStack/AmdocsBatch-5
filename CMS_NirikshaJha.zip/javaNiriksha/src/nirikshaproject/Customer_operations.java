package nirikshaproject;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.Scanner;
public class Customer_operations {
	
	private static String jdbcurl = "oracle.jdbc.driver.OracleDriver";
	private static String connstring = "jdbc:oracle:thin:@localhost:1521:XE";
	private static String username = "niriksha";
	private static String password = "pass";

	public static void main(String[] args) {
		try {
			Class.forName(jdbcurl);
			try {
				Connection dbCon = DriverManager.getConnection(connstring, username, password);
				System.out.println("Connection Successful");
				System.out.println("**************************************");
				System.out.println("Welcome to CUSTOMER MANAGEMENT SYSTEM");
				System.out.println("**************************************");

				Scanner scan=new Scanner(System.in);

				boolean onLandingPage = true;

				while(onLandingPage) {	
					
					System.out.println();
					System.out.println("1. Sign up");
					System.out.println("2. Sign in");
					System.out.println("3. Admin options");
					System.out.println("Select your option :");
					

					int userInput = scan.nextInt();

					switch (userInput) {
					case 1:
						if(signUp(dbCon, scan)==true) {
							onLandingPage = false;
						}
						break;

					case 2:
						if(signIn(dbCon, scan)==true) {
							onLandingPage = false;
						}
						break;

					case 3:
						adminOptions(dbCon, scan);
						break;

					default:
						onLandingPage = true;
						System.out.println("Invalid operation.\nSelect correct option.");
						break;
					}
				}

				if(onLandingPage == false) {

					boolean isLoggedIn = true;

					while(isLoggedIn) {


						System.out.println();
						System.out.println("1. Search customer details");
						System.out.println("2. Add new customer");
						System.out.println("3. Edit customer details");
						System.out.println("4. Remove customer");
						System.out.println("5. Logout");
						System.out.println("Select your operation :");

						int operation = scan.nextInt();

						switch (operation) {
						case 1:
							//Search customer
							System.out.println("Enter Customer id: ");
							int CustomerIdtoSearch = scan.nextInt();
							searchCustomer(dbCon,CustomerIdtoSearch );
							break;
						case 2:
							// Add customer
							addCustomer(dbCon, scan);
							break;
						case 3:
							// Update customer
							System.out.println("Enter Customer id: ");
							int CustomerIdtoUpdate = scan.nextInt();
							updateCustomer(dbCon, scan, CustomerIdtoUpdate);
							break;

						case 4:
							// Delete customer
							System.out.println("Enter Customer id: ");
							int CustomerIdtoDelete = scan.nextInt();
							deleteCustomer(dbCon, CustomerIdtoDelete);
							break;

						case 5:
							//Logout
							isLoggedIn = false;
							System.out.println("Logged out successfully.");
							break;

						default:
							System.out.println("Invalid operation.\nSelect correct option.");
							break;

						}
					}

				}

			} catch (SQLException e) {
				e.printStackTrace();
			}
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}

	private static void deleteUser(Connection dbCon, int user_id) throws SQLException {
		String deleteStmt = "DELETE FROM users WHERE user_id=?";
		try (PreparedStatement psDelete = dbCon.prepareStatement(deleteStmt)) {
			psDelete.setInt(1, user_id);
			int rowsAffected = psDelete.executeUpdate();
			if (rowsAffected > 0) {
				System.out.println("User deleted successfully.");
			} else {
				System.out.println("User not found.");
			}
		} 
		catch(SQLException e) {
			System.err.println("Error during deleting user: " + e.getMessage());
		}
	}

	private static boolean signIn(Connection dbCon, Scanner scan) {
		System.out.println("Enter user_name ");
		String user_name = scan.next();

		System.out.println("Enter user_password ");
		String user_password = scan.next();

		String userLogin = "SELECT user_name, user_password FROM users WHERE user_name = ?";

		try (PreparedStatement psLogin = dbCon.prepareStatement(userLogin)) {
			psLogin.setString(1, user_name);
			try (ResultSet result = psLogin.executeQuery()) {
				if (result.next()) {
					String dbPassword = result.getString("user_password");

					if (user_password.equals(dbPassword)) {
						System.out.println("Login Successful.");
						return true;
					} else {
						System.out.println("Login Failed: Incorrect Password.");
					}
				} else {
					System.out.println("Login Failed: User doesn't exist.");
				}
			}
		}catch(SQLException e) {
			System.err.println("Error during user sign in: " + e.getMessage());

		}
		return false;

	}

	private static boolean signUp(Connection dbCon, Scanner scan) {
		System.out.println("Enter user_name ");
		String user_name = scan.next();

		System.out.println("Enter user_password ");
		String user_password = scan.next();

		String regstmt = "INSERT INTO users (user_id, user_name, user_password) VALUES (user_id_sequence.nextval, ?, ?)";

		try (PreparedStatement psRegister = dbCon.prepareStatement(regstmt)) {
			psRegister.setString(1, user_name);
			psRegister.setString(2, user_password);
			psRegister.executeUpdate();
			System.out.println("User Registered Successfully.");
			return true;
		} catch(SQLException e) {
			System.err.println("Error during user sign Up: " + e.getMessage());
		}
		return false;
	}


	private static void adminOptions(Connection dbCon, Scanner scan) throws SQLException {
		System.out.println("Enter admin password");
		String input_pass = scan.next();
		String adminPass = "admin@101";

		if(input_pass.equals(adminPass))
		{
			System.out.println("Administrator login successful");

			boolean adminLogin = true;

			while(adminLogin) {
				System.out.println("1. View users");
				System.out.println("2. Delete user");
				System.out.println("3. Exit");

				int adminInput = scan.nextInt();

				switch (adminInput) {
				case 1:
					allUsers(dbCon);
					break;

				case 2:
					System.out.println("Enter user id to delete: ");
					int userIdtoDelete = scan.nextInt();
					deleteUser(dbCon, userIdtoDelete);
					break;

				case 3:
					return;
				default:

					System.out.println("Invalid operation.\nSelect correct option.");
					break;
				}

			}

		}
		else 
		{
			System.out.println("Wrong password.");
		}
	}


	private static void updateCustomer(Connection dbCon, Scanner scan, int customerId) {
		System.out.println("Enter type (1: Name, 2: Phone Number, 3: Address, 4: All): ");
		int type = scan.nextInt();

		String updateStmt = "";
		switch (type) {
		case 1:
			System.out.println("Enter Customer name: ");
			String customer_name = scan.next();
			updateStmt = "update customers set customer_name=? where customer_id=?";
			try (PreparedStatement psUpdate = dbCon.prepareStatement(updateStmt)) {
				psUpdate.setString(1, customer_name);
				psUpdate.setInt(2, customerId);
				executeUpdateAndPrintStatus(psUpdate);
			} catch (SQLException e) {
				handleSQLException(e);
			}
			break;
		case 2:
			System.out.println("Enter customer phone number: ");
			String phone_number = scan.next();
			updateStmt = "update customers set phone_number=? where customer_id=?";
			try (PreparedStatement psUpdate = dbCon.prepareStatement(updateStmt)) {
				psUpdate.setString(1, phone_number);
				psUpdate.setInt(2, customerId);
				executeUpdateAndPrintStatus(psUpdate);
			} catch (SQLException e) {
				handleSQLException(e);
			}
			break;
		case 3:
			System.out.println("Enter customer address: ");
			String address = scan.next();
			updateStmt = "update customers set address=? where customer_id=?";
			try (PreparedStatement psUpdate = dbCon.prepareStatement(updateStmt)) {
				psUpdate.setString(1, address);
				psUpdate.setInt(2, customerId);
				executeUpdateAndPrintStatus(psUpdate);
			} catch (SQLException e) {
				handleSQLException(e);
			}
			break;
		case 4:
			System.out.println("Enter Customer name: ");
			String updatedName = scan.next();

			System.out.println("Enter customer phone number: ");
			String updatedPhone = scan.next();

			System.out.println("Enter customer address: ");
			String updatedAddress = scan.next();

			updateStmt = "update customers set customer_name=?, phone_number=?, address=? where customer_id=?";
			try (PreparedStatement psUpdate = dbCon.prepareStatement(updateStmt)) {
				psUpdate.setString(1, updatedName);
				psUpdate.setString(2, updatedPhone);
				psUpdate.setString(3, updatedAddress);
				psUpdate.setInt(4, customerId);
				executeUpdateAndPrintStatus(psUpdate);
			} catch (SQLException e) {
				handleSQLException(e);
			}
			break;
		default:
			System.out.println("Invalid operation.");
			break;
		}
	}

	private static void executeUpdateAndPrintStatus(PreparedStatement psUpdate) throws SQLException {
		int rowsAffected = psUpdate.executeUpdate();
		if (rowsAffected > 0) {
			System.out.println("Data updated successfully.");
		} else {
			System.out.println("Customer not found.");
		}
	}

	private static void handleSQLException(SQLException e) {
		System.err.println("Error updating customer: " + e.getMessage());
	}


	private static void addCustomer(Connection con, Scanner scan) throws SQLException {
		System.out.println("Enter customer name: ");
		String customer_name = scan.next();

		System.out.println("Enter customer contact: ");
		String customer_contact = scan.next();

		System.out.println("Enter customer address: ");
		String customer_address = scan.next();

		System.out.println("Enter user_id: ");
		int user_id = scan.nextInt();

		String insertstmt = "INSERT INTO customers (customer_id, customer_name, phone_number,address, user_id) VALUES(customer_id_sequence.NEXTVAL,?,?,?,?)";

		try (PreparedStatement psinsert = con.prepareStatement(insertstmt)) {
			psinsert.setString(1, customer_name);
			psinsert.setString(2, customer_contact);
			psinsert.setString(3, customer_address);
			psinsert.setInt(4, user_id);
			psinsert.execute();
			System.out.println("Data inserted.");
		} catch(SQLException e) {
			System.err.println("Error during add customer: " + e.getMessage());

		}
	}

	
	private static void deleteCustomer(Connection dbCon, int customer_id) throws SQLException {
		String deleteStmt = "DELETE FROM customers WHERE customer_id=?";
	    try (PreparedStatement psDelete = dbCon.prepareStatement(deleteStmt)) {
	        psDelete.setInt(1, customer_id);
	        int rowsAffected = psDelete.executeUpdate();
	        if (rowsAffected > 0) {
	            System.out.println("User deleted successfully.");
	        } else {
	            System.out.println("User not found.");
	        }
	    }catch(SQLException e) {
			System.err.println("Error during delete customer: " + e.getMessage());

		}
	}
	
	private static void searchCustomer(Connection dbCon, int customer_id) throws SQLException {
		String searchStmt = "SELECT * FROM customers WHERE customer_id=?";
		try (PreparedStatement psSearch = dbCon.prepareStatement(searchStmt)) {
            psSearch.setInt(1, customer_id);
            ResultSet rs = psSearch.executeQuery();
            if (rs.next()) {
                System.out.println("Customer ID: " + rs.getInt("customer_id"));
                System.out.println("Name: " + rs.getString("customer_name"));
                System.out.println("Contact: " + rs.getString("phone_number"));
                System.out.println("Address: " + rs.getString("address"));
            } else {
                System.out.println("Customer not found.");
            }
        }catch(SQLException e) {
			System.err.println("Error during search customer: " + e.getMessage());

		}

	}
	
	private static void allUsers(Connection dbCon) throws SQLException {
	    String searchStmt = "SELECT * FROM users";
	    try (PreparedStatement psSearch = dbCon.prepareStatement(searchStmt)) {
	        ResultSet rs = psSearch.executeQuery();
	        while (rs.next()) {
	            System.out.println("User ID: " + rs.getInt("user_id"));
	            System.out.println("User Name: " + rs.getString("user_name"));
	            System.out.println("User registration date: " + rs.getTimestamp("registration_date"));
	            System.out.println(); 
	        }
	        if (!rs.isBeforeFirst()) {
	            System.out.println("No users found.");
	        }
	    } catch(SQLException e) {
			System.err.println("Error during displaying users:  " + e.getMessage());

		}
	}





}
