class Task extends Thread {
@Override
public void run() {
System.out.println(this.currentThread().getName());
}
}



public class Threading {
///thread schedular schedule threads
	/*
	 * new state 
	 * start state
	 * running state
	 * end state
	 */
	public static void main(String[] args) {
		Task t1 =new Task();
		t1.start();

	}

}
