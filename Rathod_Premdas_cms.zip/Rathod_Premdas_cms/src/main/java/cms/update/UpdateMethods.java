package cms.update;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

import cms.CustomerManageSystem;

public class UpdateMethods {
	Scanner scan = new Scanner(System.in);

	public void updateId(int id) {

	}

	public void updateName(int id) throws SQLException {
		System.out.println("give new name:");
		String newName = scan.nextLine();
		String updateName = "update cmscustomers set custName =? where custId = ?";
		PreparedStatement stmt1 = CustomerManageSystem.connectdb.conn.prepareStatement(updateName);
		stmt1.setString(1, newName);
		stmt1.setInt(2, id);
		stmt1.executeUpdate();
		System.out.println("updated " + newName + " successfully and " + " your id is: " + id);
	}

	public void updateContact(int id) throws SQLException {
		System.out.println("give new contact:");
		String newContact = scan.nextLine();
		String updateContact = "update cmscustomers set custContact =? where custId = ?";
		PreparedStatement stmt2 = CustomerManageSystem.connectdb.conn.prepareStatement(updateContact);
		stmt2.setString(1, newContact);
		stmt2.setInt(2, id);
		stmt2.executeUpdate();
		System.out.println("updated " + newContact + " successfully");
	}

	public void updateEmail(int id) throws SQLException {
		System.out.println("give new email:");
		String newEmail = scan.nextLine();
		String updateEmail = "update cmscustomers set custEmail =? where custId = ?";
		PreparedStatement stmt3 = CustomerManageSystem.connectdb.conn.prepareStatement(updateEmail);
		stmt3.setString(1, newEmail);
		stmt3.setInt(2, id);
		stmt3.executeUpdate();
		System.out.println(newEmail + " successfully updated");
	}

	public void updateAddress(int id) throws SQLException {
		System.out.println("give new address:");
		String newAddress = scan.nextLine();
		String updateaddress = "update cmscustomers set custAddress =? where custId = ?";
		PreparedStatement stmt4 = CustomerManageSystem.connectdb.conn.prepareStatement(updateaddress);
		stmt4.setString(1, newAddress);
		stmt4.setInt(2, id);
		stmt4.executeUpdate();
		System.out.println(newAddress + " successfully updated");
	}
	public void updateAllDetails(int id) throws SQLException {
		System.out.print("customer Name : ");
		 String newName = scan.nextLine();
		System.out.print("customer contact : ");
		String newContact = scan.nextLine();
		System.out.print("customer email : ");
		 String newEmail = scan.nextLine();
		System.out.print("customer address : ");
		String newAddress = scan.nextLine();
		String updateDetails = "update cmscustomers set  custName = ? custContact = ? custEmail=? custAddress=?  where custId = ?";
		PreparedStatement stmt5 = CustomerManageSystem.connectdb.conn.prepareStatement(updateDetails);
		stmt5.setString(1, newName);
		stmt5.setString(2, newContact);
		stmt5.setString(3, newEmail);
		stmt5.setString(4, newAddress);
		stmt5.setInt(5, id);
		stmt5.executeUpdate();
		System.out.println("successfully updated all details");
		
	}
//
	public void wantToUpdateData(int id) throws SQLException {
		System.out.println("want to update other record 'ýes' or 'no':");
		String input = scan.next();
		if (input.equalsIgnoreCase("yes")) {
			System.out.println(" \n1.update name\n2.contact\n3.email\n4.address");
			System.out.print("choose option:");
			String str2 = scan.nextLine();
			int changewant = Integer.parseInt(scan.nextLine());
			System.out.println("record u want to change  is " + changewant);
			switch (changewant) {
			case 1:
				updateName(id);
				break;
			case 2:
				updateContact(id);
				break;
			case 3:
				updateEmail(id);
				break;
			case 4:
				updateAddress(id);
				break;

			default:
				System.out.println("select valid input:");
				break;
			}
		}
		else {
			///going back to start of system
		}
	}

}
