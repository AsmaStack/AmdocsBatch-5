package cms;

import java.lang.management.LockInfo;
import java.nio.channels.SelectableChannel;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

import javax.swing.text.StyledEditorKit.BoldAction;

import org.w3c.dom.ls.LSOutput;

public class Login {

	String userName;
	String userPassword;
	boolean Credentials = false;
	CrudOperations crud = new CrudOperations();
	PerformOtherOperations continueOperations = new PerformOtherOperations();
	Scanner scan = new Scanner(System.in);
	Registration userRegister = new Registration();
	

//take vlaalues from user user name and passwoed
	// validate in database
	// give prompt
	// his operations

	public void login(String userName, String userPassword) throws SQLException {

		String checkLogin = "select *  from  cmsusers where username =? and userpassword=?";
		PreparedStatement psmts = CustomerManageSystem.connectdb.conn.prepareStatement(checkLogin);
		psmts.setString(1, userName);
		psmts.setString(2, userPassword);
		ResultSet result = psmts.executeQuery();
		Credentials = false;
		if (result.next()) {
			String name = result.getString(2);
			String role = result.getString(4);
			System.out.println();
			System.out.println("Logged in as " + name +" your role is "+role);

			String s1 = "admin1";
			if (role.equals(s1)) {
//				Credentials = true;
//				System.out.println("credentials :" + Credentials);
				// admin operations ->inset,,...delete
				System.out.println();
				System.out.println("Admin Operations:");
				System.out.println(
						"1.ADD CUSTOMER\n2.UPDATE CUSTOMER\n3.DELETE CUSTOMER\n4.VIEW ALL CUSTOMER\n5.SEARCH CUSTOMER BY ID\n6.add new user\n7.vew all users");
				System.out.print("Which Operation Want TO Perform:");
				int userinput = scan.nextInt();
				switch (userinput) {
				case 1:

					crud.addCustomer();
					break;
				case 2:
					crud.updateCustomer();
					break;
				case 3:
					crud.deleteCustomer();
					break;
				case 4:
					crud.viewAllCustomer();
					break;
				case 5:
					crud.serachById();
					break;
				case 6:
					userRegister.addNewUser();
					break;
				case 7:
					userRegister.viewAllUsers();
					break;

				default:
					break;
				}

			} else {
				// normal user =serach based on differnt criteria

				System.out.println("1. View all Users\n2.view all Customers\n3.search customer by Id");
				System.out.print("choose option : ");
				int value =scan.nextInt();
				
				if (value == 1) {
					userRegister.viewAllUsers();
				} else if(value == 2){
					crud.viewAllCustomer();
				}
				else {
					crud.serachById();
				}
				
			}

		} else {
			System.out.println("Please give valid user and password");
			Credentials = true;
			while (Credentials == true) {
				System.out.print("enter username : ");
				userName = scan.nextLine();
				System.out.print("enter password : ");
				userPassword = scan.nextLine();

				login(userName, userPassword);

			}
		}

//		System.out.println(invalidCredentials);
	}

	public void loginVlaidate() throws SQLException {
//		boolean otherOperation = true;
		System.out.print("enter username : ");
		userName = scan.nextLine();
		System.out.print("enter password : ");
		userPassword = scan.nextLine();
		login(userName, userPassword);
//		System.out.println(" continus operations");
		continueOperations.performOtherOperations();
//		System.out.println("exit ");// option can give

	}
}
