package cms;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;


public class dbConnection {
	public dbCredentials db = new dbCredentials();
	public Connection conn;
	public void connectToDb() {
		try {
			Class.forName(db.getDriverClassLocation());
//			System.out.println("Driver Loaded successfully");
			 conn = DriverManager.getConnection(db.getDatabaseUrl(), db.getUserName(), db.getUserPassword());
//			System.out.println("Database connected successFully");
		}

		catch (ClassNotFoundException e) {
			System.out.println("Driver Class Not Loaded ");
		} catch (SQLException e) {
			System.out.println("Database Authentication Failed give valid username and password");
		}
		
		
//		conn.close();
//		System.out.println("Connection closed sussfully");
		
		
	}

}
