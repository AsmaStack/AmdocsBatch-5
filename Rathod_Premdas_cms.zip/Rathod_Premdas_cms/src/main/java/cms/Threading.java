package cms;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

class Task extends Thread {
//@Override
//public void run() {
////System.out.println(this.currentThread().getName());
//	for( int i=1;i<=20;i++) {
//		System.out.println("first thread task2 :");
//	}
//}
}

//Thread class is parent thread

class Task2 extends Thread{
//	@Override
//	public void run() {
//	for( int i=1;i<=20;i++) {
//		System.out.println("second thread task2 :");
//	}
//		}
}
public class Threading {
///thread schedular schedule threads
	/*
	 * new state 
	 * start state
	 * running state
	 * end state
	 */
	 static Scanner scan = new Scanner(System.in);
	
		
	
	public static void main(String[] args) throws SQLException {
//		Task t1 =new Task(); //multiple copy of same unit of task this is not multiple threading copy
//		Task2 t2 =new Task2();
//		System.out.println(t1.currentThread());
//		System.out.println(t1.getState());
//		
		
//		
//;
//	
//		t1.run();
//		t2.run();
		//after thread start() immediate join() it complete that thread 
		//else if i gave after threads started then inconsistent theads run,here in need to sysnchronize threads
		
		////join()  give exceptions inttruupt and ==but not always cimplete it mix all joined threads
		//here syschronization comes into picture
		//join() that thread will complete work and then only other thread give cpu and controlling threads 
		
		System.out.println("updating customer details :");
		System.out.print("enter customer id:");
		int id = scan.nextInt();
		
		System.out.println("\nupdate's available are:");
		System.out.println(" \n1.update name\n2.contact\n3.email\n4.address");
		System.out.print("choose option:");
		scan.nextLine();
		int userInput = Integer.parseInt(scan.nextLine());
		switch (userInput) {
		case 1:
			System.out.println("give new name:");
			String newName = scan.nextLine();
//
//			String updateName = "update cmscustomers set custName =? where custId = ?";
//			PreparedStatement stmt1 = CustomerManageSystem.connectdb.conn.prepareStatement(updateName);
//			stmt1.setString(1, newName);
//			stmt1.setInt(2, id);
//			stmt1.executeUpdate();
			System.out.println("updated " + newName + " successfully");
			System.out.println("want to update any other data:");
			String c=scan.next();
			System.out.println("u opted : "+c);
			if(c.equalsIgnoreCase("yes")) {
				
//				wantToUpdate();
			}
			break;
		case 2:
			System.out.println("give new contact:");
			String newConatact = scan.nextLine();

//			String updateContact = "update cmscustomers set custContact =? where custId = ?";
//			PreparedStatement stmt2 = CustomerManageSystem.connectdb.conn.prepareStatement(updateContact);
//			stmt2.setString(1, newConatact);
//			stmt2.setInt(2, id);
//			stmt2.executeUpdate();
			System.out.println("updated " + newConatact + " successfully");

			break;
		case 3:
			System.out.println("give new email:");
			String newEmail = scan.nextLine();
//
//			String updateEmail = "update cmscustomers set custEmail =? where custId = ?";
//			PreparedStatement stmt3 = CustomerManageSystem.connectdb.conn.prepareStatement(updateEmail);
//			stmt3.setString(1, newEmail);
//			stmt3.setInt(2, id);
//			stmt3.executeUpdate();
			System.out.println(newEmail + " successfully updated");
			break;
		case 4:
			System.out.println("give new address:");
			String newAddress = scan.nextLine();

//			String updateaddress = "update cmscustomers set custAddress =? where custId = ?";
//			PreparedStatement stmt4 = CustomerManageSystem.connectdb.conn.prepareStatement(updateaddress);
//			stmt4.setString(1, newAddress);
//			stmt4.setInt(2, id);
//			stmt4.executeUpdate();
			System.out.println(newAddress + " successfully updated");
			System.out.println("want update other record ");
			String s =scan.next();
//			if(s.equalsIgnoreCase("yes"))
//				s
			break;
		default:
			break;
		}
		
		
		
		
		
		
	}

}
