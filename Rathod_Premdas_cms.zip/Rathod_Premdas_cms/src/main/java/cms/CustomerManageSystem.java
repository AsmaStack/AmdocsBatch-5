package cms;

import java.sql.SQLException;
import java.util.Scanner;

public class CustomerManageSystem {
//	public static CredentialsDB dbCredentials = new CredentialsDB();
//	public static Connection conn;

	// creating objects for
	public static Registration reg = new Registration();
	public static Login login = new Login();
	public static dbConnection connectdb = new dbConnection();

	public static void main(String[] args) throws SQLException {

		connectdb.connectToDb();
		System.out.println("****************************************************");
		System.out.println(" ");
		System.out.println("     WELCOME TO CUSTOMER MANAGEMENT SYSTEM");
		System.out.println(" ");
		
		System.out.println("****************************************************");
		System.out.println();
		System.out.println("1.New User Registration\n2.Login existing user\n3. Exit");
		System.out.println();
		System.out.print("Please select your option :");
		Scanner scan = new Scanner(System.in);
		int userInput = scan.nextInt();
		//custome exception
//		if(userInput != int)
		if (userInput == 1) {
			reg.register();
			System.out.println("want to login :");
			String s=scan.next();
			if (s.equalsIgnoreCase("yes")) {
					System.out.println("Login details verifying plese wait: ");
					login.loginVlaidate();
			} else {
				System.out.println("Exiting......");
				System.out.println("sucessfully Exited from CMS");
			}
		} else if (userInput == 2) {
			System.out.println("Login details verifying plese wait: ");
			login.loginVlaidate();

		} else {
			System.out.println("Exiting......");
			System.out.println("sucessfully Exited from CMS");
		}

	}

}
