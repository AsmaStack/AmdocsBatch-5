package cms;

import java.sql.SQLException;
import java.util.Scanner;

import cms.update.UpdateMethods;

public class PerformOtherOperations {
	boolean otherOperation =false;
	Scanner scan =new Scanner(System.in);
	CrudOperations crud2 = new CrudOperations();
	UpdateMethods update2 = new UpdateMethods();
	
 public void performOtherOperations() throws SQLException {
	 

			
				
					otherOperation =true;
					while(otherOperation ) {
						System.out.println("want to perform other operation 'yes'or 'no' :");
						String operation = scan.next();
						if (operation.equalsIgnoreCase("yes")) {
							System.out.println("Operations :");
					System.out.println("1.delete cusomer\n2.view all users\n3.serch  customer by id\n4.update customer address\n5.add customer");
					System.out.println("which operation want to perform :");
					int in = scan.nextInt();
					switch (in) {
					case 1:
						crud2.deleteCustomer();
						break;
					case 2:
						crud2.viewAllCustomer();
						break;
					case 3:crud2.serachById();

						break;
					case 4:
						System.out.println("enter customer id :");
						int cid =  scan.nextInt();
						update2.updateAddress(cid);
						break;
					case 5:
						crud2.addCustomer();
						break;

					default:
						break;
					}
					
			}
				else {
					otherOperation =false;
					System.out.println("Thanks for using CMS....");
					System.out.println("Exiting......");
					System.out.println("sucessfully Exited from CMS");

						 
				}
					}
			

		

 }
}
