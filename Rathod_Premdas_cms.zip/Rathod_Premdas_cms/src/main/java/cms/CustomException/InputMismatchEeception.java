package cms.CustomException;

import java.util.Scanner;

public class InputMismatchEeception {
	public InputMismatchEeception(String obj){
		System.out.println("Given input is not a number");
	}
	

}
