package cms;

//custId,custName,custContact,custEmail,custAddress ==table schema
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import cms.update.UpdateMethods;
import java.sql.SQLException;
import java.util.Scanner;

public class CrudOperations {
//insert customer details 
	// update
	String custName;
	String custContact;
	String custEmail;
	String custAddress;
	int id;
	Scanner scan = new Scanner(System.in);
	UpdateMethods update = new UpdateMethods();

	public void takeCustomerInput() {
		// taking input for user registration
		System.out.println("Give Customer Details:");
		System.out.print("customer Name : ");
		custName = scan.nextLine();
		System.out.print("customer contact : ");
		custContact = scan.nextLine();
		System.out.print("customer email : ");
		custEmail = scan.nextLine();
		System.out.print("customer address : ");
		custAddress = scan.nextLine();
	}

	public void addCustomer() throws SQLException {

		takeCustomerInput();
		// id,name,contact,email,address
		String insert = "insert into cmsCustomers  (custId,custName,custContact,custEmail,custAddress) values (customer_seq.nextval,?,?,?,?)";
		PreparedStatement prepareStmt = CustomerManageSystem.connectdb.conn.prepareStatement(insert);
////		prepareStmt.setInt(1, "seq_id.nextval);
		prepareStmt.setString(1, custName);
		prepareStmt.setString(2, custContact);
		prepareStmt.setString(3, custEmail);
		prepareStmt.setString(4, custAddress);
		prepareStmt.executeUpdate();
		System.out.println("Added Customer " + custName + " details");

	}

	// update customer
	public void updateCustomer() throws SQLException {
		System.out.println("updating customer details :");
		System.out.print("enter customer id:");
		id = scan.nextInt();
		System.out.println("\nupdate's available are:");
		System.out.println(" \n1.update name\n2.contact\n3.email\n4.address\n5.update all details");
		System.out.print("choose option:");
		String str = scan.nextLine();
		int userInput = Integer.parseInt(scan.nextLine());
//		int userInput = update.wantToUpdateData();
		switch (userInput) {
		case 1:

			update.updateName(id);
//			update.wantToUpdateData(id);

			break;
		case 2:

			update.updateContact(id);
//			update.wantToUpdateData(id);

			break;
		case 3:

			update.updateEmail(id);
//			update.wantToUpdateData(id);

			break;
		case 4:

			update.updateAddress(id);
//			update.wantToUpdateData(id);
			break;
		case 5:
			update.updateAllDetails(id);
			break;
		default:
			break;
		}

	}

	// deltete customer record
	public void deleteCustomer() throws SQLException {
		System.out.println("enter customer id :");
		Scanner scan = new Scanner(System.in);
		 int deleteId = scan.nextInt();
		String deleteQuery ="delete  from cmscustomers where custId =? ";
		PreparedStatement deleteps = CustomerManageSystem.connectdb.conn.prepareStatement(deleteQuery);
	deleteps.setInt(1, deleteId);
	 int RowsCount =deleteps.executeUpdate();
	 if(RowsCount > 0)
		 System.out.println("customer Id "+deleteId+" Data Deleted successfully ");
	 else {
		System.out.println(deleteId +" data not Found");
	}
	}

	// viewCustomer
	public void viewAllCustomer() throws SQLException {
//		System.out.println("Give Customer Details:");
//		takeCustomerInput();
		// id,name,contact,email,address
		String serachAll = "select * from cmscustomers ";
		PreparedStatement prepareStmt = CustomerManageSystem.connectdb.conn.prepareStatement(serachAll);

		ResultSet allCustomers = prepareStmt.executeQuery();
		System.out.println("all custoers are: ");
		System.out.println("----------------------------------------------");
		System.out.println("id    name      contact     email    address ");
		System.out.println("-----------------------------------------------");
		while (allCustomers.next()) {

			System.out.print(allCustomers.getInt(1) + " ");
			System.out.print(allCustomers.getString(2) + " ");
			System.out.print(" " + allCustomers.getString(3) + " ");
			System.out.print(" " + allCustomers.getString(4) + " ");
			System.out.print(allCustomers.getString(5) + " ");
			System.out.println("\n---------------------------------------------");
		}

	}

	// search by customer id
	public void serachById() throws SQLException {
		System.out.println("enter customer id : ");
		int custId = scan.nextInt();
		String searchId = "select * from cmscustomers where custId =?";
		PreparedStatement search = CustomerManageSystem.connectdb.conn.prepareStatement(searchId);
		search.setInt(1, custId);
		ResultSet resultId = search.executeQuery();
		System.out.println("all custoers are: ");
		System.out.println("----------------------------------------------");
		System.out.println("id    name      contact     email    address ");
		System.out.println("-----------------------------------------------");
		while (resultId.next()) {

			System.out.print(resultId.getInt(1) + " ");
			System.out.print(resultId.getString(2) + " ");
			System.out.print(" " + resultId.getString(3) + " ");
			System.out.print(" " + resultId.getString(4) + " ");
			System.out.print(resultId.getString(5) + " ");
			System.out.println("\n---------------------------------------------");
		}
	}

}
